# Frontend

This directory is reserved for a minimal React console that allows users to submit queries to the RAG API and visualise the retrieved contexts and citations.  The implementation is left as an exercise.