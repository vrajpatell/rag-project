"""Retrieve top‑k relevant chunks from the vector store."""

from typing import List, Dict, Any
import numpy as np

from sentence_transformers import SentenceTransformer
from ..vector_store.faiss_index import FaissIndex


class Retriever:
    def __init__(self, index_path: str | None = None, model_name: str = "all-MiniLM-L6-v2") -> None:
        self.embedder = SentenceTransformer(model_name)
        # Default path to FAISS index
        path = index_path or "vector_store/faiss.index"
        self.index = FaissIndex(path)

    def retrieve(self, query: str, top_k: int = 8) -> List[Dict[str, Any]]:
        query_vec = self.embedder.encode([query], convert_to_numpy=True)
        dists, idxs = self.index.search(query_vec, top_k)
        results: List[Dict[str, Any]] = []
        for distance, idx in zip(dists[0], idxs[0]):
            results.append(
                {
                    "doc_id": int(idx),
                    "score": float(distance),
                    "text": f"Document {idx}",
                    "meta": {},
                }
            )
        return results