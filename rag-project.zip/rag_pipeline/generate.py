"""Generate an answer given retrieved contexts."""

from typing import List, Dict, Any


def synthesize_answer(query: str, contexts: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Combine the query and contexts to produce an answer.

    This stub simply echoes the query and includes dummy citations.
    """
    citations = [f"[{ctx['doc_id']}]" for ctx in contexts]
    answer = f"Answer to '{query}' citing {', '.join(citations)}."
    confidence = 0.5  # dummy confidence score
    return {
        "query": query,
        "retrieved_contexts": contexts,
        "synthesized_answer": answer,
        "confidence_score": confidence,
        "citations": citations,
    }